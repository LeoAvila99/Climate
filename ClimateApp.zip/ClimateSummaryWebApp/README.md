﻿# Climate Summary Application

This application is a two page application designed to utilize various web technologies as described below in Built With section.  


# Getting Started

The application is packaged in a archived file called ClimateApp.  The application was developed in Eclipse IDE 2019-06.  The application has an embedded Tomcat web server so there is no need to install a local server.

## Prerequisites

An Eclipse IDE must be installed in your system. 

## Installing and running the application

Copy the ClimateApp archived file to your local hard drive.  Extract the archived file into a  work folder.  In the Eclipse IDE, select File->Open Projects from File System. In the Import Projects from File System or Archive, in the Import Source, navigate to the work folder and select the ClimateSummaryWebApp and click Finish.  The system will import the project and it will be shown in the Project Explorer in workbench.  To run the application, select the ClimateSummaryWebApp project, right-click and select Run As->Java Application.  The system will start the application and you can view the progress in the Console tab.  Open a browser and enter "http://localhost:8080/climate/summary" in the URL field.  The application will show the Summary page.  In the summary page, user can select a date range and the application will display the data within the selected date range.  To go to the detail page, click on the Mean Temp column.

## Running the tests

In the Eclipse workbench, select the ClimateSummaryWebApp project, right-click and select Run As->JUnit Test.  The system will run the test cases and the result can be viewed in JUnit tab.

## Built With

 - Spring Boot
 - Spring MVC
 - Thymeleaf
 - Log4j
 - Maven
 - JUnit
 - CSS

## Acknowledgments

The application uses the versatile date range picker JS by Dan Grossman. It also use CSS stylesheets from w3schools.com.
