package com.quiz;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;

import com.quiz.ClimateDataHelper;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes = TestConfig.class, loader = AnnotationConfigContextLoader.class)
public class ClimateSummaryWebAppApplicationTests {

	@Autowired
	private ClimateDataHelper climateDataHelper;
	
	@Test
	public void testDataLoad() {
		List<ClimateDetail> listDetail = climateDataHelper.getClimateData();
		assertNotNull("Province not null", listDetail.get(0).getProvince());
	};
	
	@Test
	public void testClimateDetail() {
		ClimateDetail climateDetail = climateDataHelper.getClimateDetail("CHEMAINUS");
		assertEquals("CHEMAINUS", climateDetail.getStationName());
	}
	
	@Test
	public void testClimateSummary() {
		List<ClimateSummary> climateSummary = climateDataHelper.getClimateSummaryList();
		assertNotNull("Station name not null", climateSummary.get(0).getStationName());
	}
	
	@Test
	public void testFilterClimateSummary() {
		List<ClimateSummary> climateSummary = climateDataHelper.getFilterClimateSummaryList("10/01/2018 - 10/31/2018");
		assertNotNull("Station name not null", climateSummary.get(0).getStationName());
	}
	
}
