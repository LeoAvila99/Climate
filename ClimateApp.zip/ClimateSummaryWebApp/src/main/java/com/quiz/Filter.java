package com.quiz;

public class Filter {
	private String DateRange;
	
	public Filter() {
		this.DateRange="";
	}
	public Filter(String dateRange) {
		this.DateRange = dateRange;
	}
	public String getDateRange() {
		return this.DateRange;
	}
	public void setDateRange(String dateRange) {
		this.DateRange = dateRange;
	}

}
