package com.quiz;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ClimateConfiguration {

	@Bean
	public ClimateData getClimateData() {
		return new ClimateData();
	}

}
