package com.quiz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


@SpringBootApplication
public class ClimateSummaryWebAppApplication {
	
	private static final Logger logger = LogManager.getLogger(ClimateSummaryWebAppApplication.class);
	public static void main(String[] args) {
		SpringApplication.run(ClimateSummaryWebAppApplication.class, args);
		logger.debug("Started application");
			
	}

}
