package com.quiz;

public class ClimateDetail {
	private String stationName;
	private String date;
	private String meanTemp;
	private String province;
	private String highestMonthlyMaxiTemp;
	private String lowestMonthlyMinTemp;
	public ClimateDetail(String stationName, String date, String meanTemp, String province, 
			String highestMonthlyMaxiTemp, String lowestMonthlyMinTemp) {
		this.stationName = stationName;
		this.date = date;
		this.meanTemp = meanTemp;
		this.province = province;
		this.highestMonthlyMaxiTemp = highestMonthlyMaxiTemp;
		this.lowestMonthlyMinTemp = lowestMonthlyMinTemp;
	}
	public String getStationName() {
		return stationName;
	}
	public String getDate() {
		return date;
	}
	public String getMeanTemp() {
		return meanTemp;
	}
	public String getProvince() {
		return province;
	}
	public String getHighestMonthlyMaxiTemp() {
		return highestMonthlyMaxiTemp;
	}
	public String getLowestMonthlyMinTemp() {
		return lowestMonthlyMinTemp;
	}

}
