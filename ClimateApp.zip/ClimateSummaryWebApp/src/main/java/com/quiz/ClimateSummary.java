package com.quiz;

public class ClimateSummary {
	private String stationName;
	private String date;
	private String meanTemp;
	public ClimateSummary(String stationName, String date, String meanTemp) {
		super();
		this.stationName = stationName;
		this.date = date;
		this.meanTemp = meanTemp;
	}
	public String getStationName() {
		return stationName;
	}
	public void setStationName(String stationName) {
		this.stationName = stationName;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getMeanTemp() {
		return meanTemp;
	}
	public void setMeanTemp(String meanTemp) {
		this.meanTemp = meanTemp;
	}
	
}
