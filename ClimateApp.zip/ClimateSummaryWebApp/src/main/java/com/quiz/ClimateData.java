package com.quiz;

import java.util.List;

public class ClimateData {
	static List<ClimateDetail> listClimateDetail = null;

	public ClimateData() {
		if (listClimateDetail == null) {
			ClimateDataHelper helper = new ClimateDataHelper();
			listClimateDetail = helper.getClimateData();
		}
	}

	public List<ClimateDetail> getClimateData() {
		return listClimateDetail;
	}
}
