package com.quiz;

import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class ClimateDataHelper {
	
	private static final Logger logger = LogManager.getLogger(ClimateDataHelper.class);

	public List<ClimateDetail> getClimateData() {
		
		List<ClimateDetail> listClimateDetail = new ArrayList<ClimateDetail>();
		String SAMPLE_CSV_FILE_PATH = "./src/main/resources/eng-climate-summary.csv";

		logger.debug("Reading data from file");

		try {
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			SimpleDateFormat formatter2 = new SimpleDateFormat("MM/dd/yyyy");

			Reader reader = Files.newBufferedReader(Paths.get(SAMPLE_CSV_FILE_PATH));
	        CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT
	                    .withFirstRecordAsHeader()
	                    .withIgnoreHeaderCase()
	                    .withTrim());
	        for (CSVRecord csvRecord : csvParser) {
	             String stationName = csvRecord.get(0);
            	 String province = csvRecord.get(1);
            	 Date date = formatter.parse(csvRecord.get(2));
            	 String sDate = formatter2.format(date);
            	 String meanTemp = csvRecord.get(3);
            	 String min = csvRecord.get(4);
            	 String max = csvRecord.get(5);
            	 listClimateDetail.add(new ClimateDetail(stationName, sDate, meanTemp, province, min, max));
	        }
	        csvParser.close();
		} catch(Exception e) {
			logger.error("Error:" + e.toString());
		}
		return listClimateDetail;
	}
	
	public List<ClimateSummary> getClimateSummaryList() {
		
		List<ClimateSummary> listClimateSummary = new ArrayList<ClimateSummary>();
		AnnotationConfigApplicationContext ctx = 
				new AnnotationConfigApplicationContext(ClimateConfiguration.class);
		ClimateData cd = ctx.getBean(ClimateData.class);
		ctx.close();
		Iterator<ClimateDetail> it = cd.getClimateData().iterator();
		while (it.hasNext()) {
			ClimateDetail detail = it.next();
            listClimateSummary.add(new ClimateSummary(detail.getStationName(), detail.getDate(), detail.getMeanTemp()));
		}
		return listClimateSummary;
	}
	
	public List<ClimateSummary> getFilterClimateSummaryList(String dateRange) {
		
		List<ClimateSummary> listClimateSummary = new ArrayList<ClimateSummary>();
		try {
			String[] arrOfStr = dateRange.split("-", 2);
			SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
			Date fromDate = formatter.parse(arrOfStr[0]);
			Date toDate = formatter.parse(arrOfStr[1]);
			listClimateSummary = new ArrayList<ClimateSummary>();
			AnnotationConfigApplicationContext ctx = 
				new AnnotationConfigApplicationContext(ClimateConfiguration.class);
			ClimateData cd = ctx.getBean(ClimateData.class);
			ctx.close();
			Iterator<ClimateDetail> it = cd.getClimateData().iterator();
			while (it.hasNext()) {
				ClimateDetail detail = it.next();
                Date dateTemp = formatter.parse(detail.getDate());
                if ((dateTemp.compareTo(fromDate) >= 0) && (dateTemp.compareTo(toDate) <= 0)) {
                	listClimateSummary.add(new ClimateSummary(detail.getStationName(), detail.getDate(), detail.getMeanTemp()));
                }
			}
		} catch(Exception e) {
			logger.error("Error:" + e.toString());
		}
		if (listClimateSummary.isEmpty()) {
			logger.warn("Warning: Requested " + dateRange + " date range did not return any result.");
		}
		return listClimateSummary;
	}
	
	public ClimateDetail getClimateDetail(String stationNameId) {
		ClimateDetail climateDetail = null;
		AnnotationConfigApplicationContext ctx = 
				new AnnotationConfigApplicationContext(ClimateConfiguration.class);
		ClimateData cd = ctx.getBean(ClimateData.class);
		ctx.close();
		Iterator<ClimateDetail> it = cd.getClimateData().iterator();
		while (it.hasNext()) {
			ClimateDetail detail = it.next();
			if (detail.getStationName().equals(stationNameId)) {
               	climateDetail = new ClimateDetail(detail.getStationName(), detail.getDate(), detail.getMeanTemp(), detail.getProvince(), 
               			detail.getLowestMonthlyMinTemp(), detail.getHighestMonthlyMaxiTemp());
            }
		}
		if (climateDetail == null) {
			logger.warn("Warning: Requested " + stationNameId + " details not found.");
		}
		return climateDetail;
	}
}
