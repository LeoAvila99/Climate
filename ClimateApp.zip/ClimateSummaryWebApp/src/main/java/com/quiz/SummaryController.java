package com.quiz;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class SummaryController {

	private static final Logger logger = LogManager.getLogger(DetailController.class);

	@GetMapping("/summary")
	public String displaySummary(Model model) {
		ClimateDataHelper helper = new ClimateDataHelper();
		List<ClimateSummary> climateSummary = helper.getClimateSummaryList();
		
		model.addAttribute("climateSummary", climateSummary);
		model.addAttribute("filter", new Filter());
		return "climateSummary";
	}
	
	@PostMapping("/filterSummary")
	public String displayFilterSummary(@ModelAttribute Filter filter, Model model) {
		logger.debug("User requested date range:" + filter.getDateRange());
		if (filter.getDateRange() == null) {
			model.addAttribute("message", "No date range selected");
			return "appError";
		}
		ClimateDataHelper helper = new ClimateDataHelper();
		List<ClimateSummary> climateSummary = helper.getFilterClimateSummaryList(filter.getDateRange());
		
		model.addAttribute("climateSummary", climateSummary);
		return "climateSummary";
	}
	
}
